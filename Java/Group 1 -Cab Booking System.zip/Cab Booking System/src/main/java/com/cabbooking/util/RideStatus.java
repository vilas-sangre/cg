package com.cabbooking.util;

public enum RideStatus {
	SCHEDULED, ONGOING, COMPLETED, CANCELED
}
