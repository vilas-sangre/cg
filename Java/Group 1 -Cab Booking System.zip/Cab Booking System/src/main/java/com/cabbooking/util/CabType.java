package com.cabbooking.util;

public enum CabType {
	SEDAN, SUV , HATCHBACK

}
