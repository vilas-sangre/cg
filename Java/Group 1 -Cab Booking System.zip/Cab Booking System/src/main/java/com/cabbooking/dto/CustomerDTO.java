package com.cabbooking.dto;

public class CustomerDTO extends UserDTO {
	
	private String customerName;
}
