package com.cabbooking.exception;

public class GlobalExceptionHandler {

}
