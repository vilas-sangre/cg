package com.cabbooking.exception;

public class CabBookingException extends Exception {
	public CabBookingException(String message) {
		super(message);
	}

}
