package com.cabbooking.dto;

public class UserDTO {
	private Integer userId;
	private String userName;
	private String password;
	private String address;
	private String mobileNumber;
	private String email;
	//Admin, Customer, Driver
	private String roles;
}