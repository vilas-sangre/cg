package com.cabbooking.dto;

public class DriverDTO extends UserDTO {

	private String driverName;
	private String licenseNo;
	private Boolean driverAvailability;
	
}