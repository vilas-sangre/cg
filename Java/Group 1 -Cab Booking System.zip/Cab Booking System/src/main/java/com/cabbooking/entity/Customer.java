package com.cabbooking.entity;

public class Customer extends User {
	
	private String customerName;
}
