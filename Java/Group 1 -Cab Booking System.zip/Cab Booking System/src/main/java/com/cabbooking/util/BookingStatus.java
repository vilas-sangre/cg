package com.cabbooking.util;

public enum BookingStatus {
	PENDING, CONFIRMED, CANCELED

}
