package com.cabbooking.entity;

public class Driver extends User {

	private String driverName;
	private String licenseNo;
	private Boolean driverAvailability;
	
}