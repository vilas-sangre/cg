package com.bugtracking.dto;

import java.util.List;

public class ProjectDTO {

	private Integer projId;
	private String projName;
	private String projectDescription;
	private String projStatus;
	private List<DeveloperDTO> devList;
	private List<TestEngineerDTO> testEngList;
	

}
