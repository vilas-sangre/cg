package com.bugtracking.entity;

import java.time.LocalDate;

import com.bugtracking.util.BugStatus;
import com.bugtracking.util.Severity;

public class Bug {

	private Integer bugId;
	private String bugTitle;
	private String bugDescription;
	private Severity severity;
	private TestEngineer createdBy;
	private Developer assignTo;
	private BugStatus status;
	private LocalDate startDate;
	private LocalDate lastUpdatedDate;
	private Project project;

}
