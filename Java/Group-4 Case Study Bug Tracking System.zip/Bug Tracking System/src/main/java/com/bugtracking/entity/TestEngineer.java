package com.bugtracking.entity;

import java.util.List;

public class TestEngineer extends User {

	private String testerName;
	private String testerSkill;
	private List<Project> project;
}
