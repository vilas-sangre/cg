package com.bugtracking.service;

import java.util.List;

import com.bugtracking.dto.ProjectDTO;
import com.bugtracking.dto.TestEngineerDTO;

public interface ITestEngineerService {

	TestEngineerDTO addTestEngineer(TestEngineerDTO testEngineer);

	TestEngineerDTO updateTestEngineer(TestEngineerDTO testEngineer);

	TestEngineerDTO getTestEngById(Integer testerId);

	List<TestEngineerDTO> getAllTesters();

	List<ProjectDTO> getProjectByTestEngId(Integer testEngId);

}
