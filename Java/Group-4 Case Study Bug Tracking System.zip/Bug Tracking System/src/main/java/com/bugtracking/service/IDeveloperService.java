package com.bugtracking.service;

import java.util.List;

import com.bugtracking.dto.DeveloperDTO;
import com.bugtracking.dto.ProjectDTO;

public interface IDeveloperService {
	DeveloperDTO addDeveloper(DeveloperDTO developer);

	DeveloperDTO updateDeveloper(DeveloperDTO developer);

	DeveloperDTO getDeveloperById(Integer devId);

	List<DeveloperDTO> getAllDevelopers();

	List<ProjectDTO> getProjectByDevId(Integer devId);
}
