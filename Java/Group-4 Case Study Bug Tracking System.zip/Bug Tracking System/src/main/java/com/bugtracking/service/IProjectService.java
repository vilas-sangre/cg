package com.bugtracking.service;

import java.util.List;

import com.bugtracking.dto.DeveloperDTO;
import com.bugtracking.dto.ProjectDTO;
import com.bugtracking.dto.TestEngineerDTO;

public interface IProjectService {

	ProjectDTO createProject(ProjectDTO projDTO);

	ProjectDTO getProjectById(Integer projId);

	List<ProjectDTO> getAllProjects();

	ProjectDTO updateProject(ProjectDTO projDTO);

	List<DeveloperDTO> getDevelopersByProjectId(Integer projId);

	List<TestEngineerDTO> getTestEngineersByProjectId(Integer projId);

}
