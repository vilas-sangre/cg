package com.bugtracking.dto;

import java.util.List;

public class DeveloperDTO extends UserDTO {

	private String devName;
	private String devSkill;
	private List<ProjectDTO> project;

}