package com.bugtracking.entity;

import java.util.List;

public class Project {

	private Integer projId;
	private String projName;
	private String projectDescription;
	private String projStatus;
	private List<Developer> devList;
	private List<TestEngineer> testEngList;

}
