package com.bugtracking.exception;

public class GlobalExceptionHandler {

}
