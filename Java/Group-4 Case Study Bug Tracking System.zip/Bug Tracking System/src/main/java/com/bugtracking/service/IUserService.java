package com.bugtracking.service;

import com.bugtracking.dto.UserDTO;

public interface IUserService {
	UserDTO registerUser(UserDTO user);

	UserDTO signIn(String userName, String password);

	// use session management accordingly
	String signOut();
}
