package com.bugtracking.dto;

import java.time.LocalDate;

import com.bugtracking.util.BugStatus;
import com.bugtracking.util.Severity;

public class BugDTO {

	private Integer bugId;
	private String bugTitle;
	private String bugDescription;
	private Severity severity;
	private TestEngineerDTO createdBy;
	private DeveloperDTO assignTo;
	private BugStatus status;
	private LocalDate startDate;
	private LocalDate lastUpdatedDate;
	private ProjectDTO project;

}
