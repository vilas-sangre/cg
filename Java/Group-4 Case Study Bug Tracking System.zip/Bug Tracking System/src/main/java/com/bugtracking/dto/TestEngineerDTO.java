package com.bugtracking.dto;

import java.util.List;

public class TestEngineerDTO extends UserDTO {

	private String testerName;
	private String testerSkill;
	private List<ProjectDTO> project;
}
