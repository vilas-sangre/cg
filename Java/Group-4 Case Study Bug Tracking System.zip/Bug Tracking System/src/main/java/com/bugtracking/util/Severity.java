package com.bugtracking.util;

public enum Severity {
	LOW, HIGH, MEDIUM
}
