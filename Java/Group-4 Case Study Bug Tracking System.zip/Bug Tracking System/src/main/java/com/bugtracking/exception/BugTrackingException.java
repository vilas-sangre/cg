package com.bugtracking.exception;

public class BugTrackingException extends Exception {

	public BugTrackingException(String message) {
		super(message);
	}
}
