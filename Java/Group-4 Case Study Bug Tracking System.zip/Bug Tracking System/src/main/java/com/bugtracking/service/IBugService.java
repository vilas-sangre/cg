package com.bugtracking.service;

import java.time.LocalDate;
import java.util.List;

import com.bugtracking.dto.BugDTO;
import com.bugtracking.dto.ProjectDTO;

public interface IBugService {
	BugDTO createBug(BugDTO bugDTO);

	BugDTO updateBug(BugDTO bugDTO);

	BugDTO findBugById(Integer bugId);

	List<BugDTO> findAllBugs();

	List<BugDTO> findAllBugsByProjectId(Integer projId);

	List<BugDTO> findBugsAssignedToDeveloper(Integer devId);

	List<BugDTO> findBugsAssignedToDeveloperByStatus(Integer devId, String status);

	List<BugDTO> findBugsByStatus(String status);

	List<BugDTO> findBugsBySeverity(String severity);

	List<BugDTO> findBugsByDate(LocalDate date);

	List<BugDTO> findBugsByDevIdAndDate(Integer devId, LocalDate startDate, LocalDate endDate);

	List<BugDTO> findBugsCreatedByTestEngineer(Integer testEngId);
	
	List<BugDTO> findBugsByProjectIdAndDevId(Integer projId,Integer devId);
	
	List<BugDTO> findBugsByProjectIdAndTestEngId(Integer projId,Integer testEngId);

}
