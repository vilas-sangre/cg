package com.bugtracking.entity;

import java.util.List;

public class Developer extends User {

	private String devName;
	private String devSkill;
	private List<Project> project;

}