package com.flightmgmt.entity;

public class Airport {
	private Integer airportid;
	private String airportName;
	private String airportCity;
	private String airportCountry;

}
