package com.flightmgmt.dto;

import java.time.LocalDate;
import java.util.List;

import com.flightmgmt.entity.Flight;

public class ScheduleDTO {
	private Integer scheduleId;
	private AirportDTO sourceAirport;
	private AirportDTO destinationAirport;
	private LocalDate arrivalDate;
	private LocalDate departureDate;

}
