package com.flightmgmt.exception;

public class FlightMgmtException extends Exception {
	public FlightMgmtException(String message) {
		super(message);
	}
}
