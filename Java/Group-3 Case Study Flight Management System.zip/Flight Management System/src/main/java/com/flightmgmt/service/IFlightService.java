package com.flightmgmt.service;

import java.time.LocalDate;
import java.util.List;

import com.flightmgmt.dto.FlightDTO;

public interface IFlightService {

	public FlightDTO addFlight(FlightDTO flight);

	public FlightDTO viewByFlightId(Integer flightId);

	public List<FlightDTO> viewAllFlights();

	public List<FlightDTO> viewByFlightName();

	public List<FlightDTO> viewByFlightSeatCapacity();

	public List<FlightDTO> viewBySourceDestination(String source, String destination);

	public List<FlightDTO> viewByDepartureDate(LocalDate date);

	public List<FlightDTO> viewBySourceDestinationAndDepartureDate(String source, String destination,
			LocalDate departureDate);

	public FlightDTO updateFlight(FlightDTO flight);

}
