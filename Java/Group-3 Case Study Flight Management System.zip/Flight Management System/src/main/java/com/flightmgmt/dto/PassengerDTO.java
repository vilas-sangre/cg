package com.flightmgmt.dto;

public class PassengerDTO extends UserDTO {

	private String passengerName;
	private Integer age;
	private Long passengerUIN;

}
