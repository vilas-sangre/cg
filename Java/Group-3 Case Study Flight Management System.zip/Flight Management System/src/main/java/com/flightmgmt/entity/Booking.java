package com.flightmgmt.entity;

import java.time.LocalDate;
import java.util.List;

public class Booking {

	private Integer bookingId;
	private Passenger passenger;
	private LocalDate bookingDate;
	private List<Passenger> passengerList;
	private Double totalCost;
	private Flight flight;
	private Integer noOfPassengers;

}
