package com.flightmgmt.entity;

import java.time.LocalDate;
import java.util.List;

public class Schedule {
	private Integer scheduleId;
	private Airport sourceAirport;
	private Airport destinationAirport;
	private LocalDate arrivalDate;
	private LocalDate departureDate;
		
}
