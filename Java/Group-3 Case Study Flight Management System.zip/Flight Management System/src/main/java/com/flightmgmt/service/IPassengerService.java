package com.flightmgmt.service;

import java.util.List;

import com.flightmgmt.dto.PassengerDTO;

public interface IPassengerService {
	PassengerDTO addPassenger(PassengerDTO passenger);

	List<PassengerDTO> viewAllPassenger();

	PassengerDTO viewPassengerByUIN(Long uin);

	PassengerDTO viewPassengerByMobileNo(Long contactNo);

}
