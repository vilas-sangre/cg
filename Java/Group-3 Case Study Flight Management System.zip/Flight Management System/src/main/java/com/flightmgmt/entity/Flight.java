package com.flightmgmt.entity;

import java.util.List;

public class Flight {
	private Integer flightId;
	private String flightName;
	private Integer seatCapacity;
	private Double fare; // cost per seat
	private List<Schedule> schedules;
}
