package com.flightmgmt.dto;

public class AirportDTO {
	private Integer airportid;
	private String airportName;
	private String airportCity;
	private String airportCountry;

}
