package com.flightmgmt.entity;

public class Passenger extends User {

	private String passengerName;
	private Integer age;
	private Long passengerUIN;

}
