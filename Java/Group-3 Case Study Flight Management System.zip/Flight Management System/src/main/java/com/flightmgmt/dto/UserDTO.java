package com.flightmgmt.dto;

public class UserDTO {
	private Long userId;
	private String userName;
	private String password;
	private String email;
	private Long mobileNumber;
	// Admin , Passenger
	private String userRole;

}
