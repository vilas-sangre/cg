
package com.flightmgmt.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.flightmgmt.dto.ScheduleDTO;

public interface IScheduleService {
	public ScheduleDTO addSchedule(ScheduleDTO schedule);

	public ScheduleDTO updateSchedule(ScheduleDTO schedule);

	public List<ScheduleDTO> viewSchedules();

	public List<ScheduleDTO> viewBySourceAndDestination(String source, String destination);

	public List<ScheduleDTO> viewBySourceDestinationAndDepartureDate(String source, String destination,
			LocalDate departureDate);

	public List<ScheduleDTO> viewByDepartureTime(LocalDateTime dateTime);

}
