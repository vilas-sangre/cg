package com.flightmgmt.dto;

import java.util.List;

public class FlightDTO {
	private Integer flightId;
	private String flightName;
	private Integer seatCapacity;
	private Double fare; // cost per seat
	private List<ScheduleDTO> schedules;
}
