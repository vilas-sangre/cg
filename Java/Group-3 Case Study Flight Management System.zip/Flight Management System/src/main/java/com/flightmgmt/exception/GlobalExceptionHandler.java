package com.flightmgmt.exception;

public class GlobalExceptionHandler {

}
