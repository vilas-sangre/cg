package com.flightmgmt.entity;

public class User {
	private Long userId;
	private String userName;
	private String password;
	private String email;
	private Long mobileNumber;
	//Admin, Passengers
	private String userRole;

}
