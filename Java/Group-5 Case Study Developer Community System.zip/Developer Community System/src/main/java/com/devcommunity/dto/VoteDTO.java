package com.devcommunity.dto;

import com.devcommunity.util.VoteType;

public class VoteDTO {
	private Integer voteId;
	private VoteType voteType;
	private DeveloperDTO developerWhoVoted;
}
