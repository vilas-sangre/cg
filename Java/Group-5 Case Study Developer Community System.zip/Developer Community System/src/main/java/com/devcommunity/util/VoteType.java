package com.devcommunity.util;

public enum VoteType {
	UPVOTE,DOWNVOTE
}
