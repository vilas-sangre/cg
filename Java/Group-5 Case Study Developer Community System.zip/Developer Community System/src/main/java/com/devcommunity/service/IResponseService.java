package com.devcommunity.service;

import java.util.List;

import com.devcommunity.dto.ResponseDTO;
import com.devcommunity.dto.VoteDTO;

public interface IResponseService {

	ResponseDTO  addResponse(ResponseDTO  response);

	ResponseDTO  updateResponse(ResponseDTO  response);

	ResponseDTO  removeResponse(Integer respId);

	List<ResponseDTO > getResponseByPost(Integer postId);

	Integer getNoOfVotesOnResponseByVoteType(String  voteType, Integer resId);

	List<ResponseDTO > getResponseByDeveloper(Integer devId);

}
