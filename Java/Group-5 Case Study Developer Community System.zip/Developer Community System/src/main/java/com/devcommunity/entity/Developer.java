package com.devcommunity.entity;

import java.time.LocalDate;
import java.util.List;

public class Developer extends User {
	private String devName;
	private String devSkill;
	private LocalDate memberSince;
	// If no. of Upvote on Post is 5, then reputation value is 1
	// If no. of Upvote on Post is 10, then reputation value is 2 and so on
	private Integer reputation;
	// Block or Unblock
	private String status;
	private List<Post> listOfPosts;

}