package com.devcommunity.entity;

import java.time.LocalDateTime;
import java.util.List;

public class Response {

	private Integer respId;
	private String answer;
	private LocalDateTime respDateTime;
	private Post post;
	private Developer developer;
	private List<Comment> listOfComments;
	private List<Vote> vote;

}
