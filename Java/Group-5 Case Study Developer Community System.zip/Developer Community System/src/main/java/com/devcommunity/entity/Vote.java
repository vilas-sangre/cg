package com.devcommunity.entity;

import com.devcommunity.util.VoteType;

public class Vote {
	private Integer voteId;
	private VoteType voteType;
	private Developer developerWhoVoted;
}
