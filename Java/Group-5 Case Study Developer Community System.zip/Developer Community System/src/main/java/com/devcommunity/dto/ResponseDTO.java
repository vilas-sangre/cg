package com.devcommunity.dto;

import java.time.LocalDateTime;
import java.util.List;

public class ResponseDTO {

	private Integer respId;
	private String answer;
	private LocalDateTime respDateTime;
	private PostDTO post;
	private DeveloperDTO developer;
	private List<CommentDTO> listOfComments;
	private List<VoteDTO> vote;

}
