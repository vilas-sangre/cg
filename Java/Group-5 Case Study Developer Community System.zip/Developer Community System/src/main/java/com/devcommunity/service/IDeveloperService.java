package com.devcommunity.service;

import java.util.List;

import com.devcommunity.dto.DeveloperDTO;
import com.devcommunity.dto.PostDTO;

public interface IDeveloperService {

	DeveloperDTO addDeveloper(DeveloperDTO developer);

	DeveloperDTO updateDeveloper(DeveloperDTO developer);

	List<DeveloperDTO> getDeveloperByStatus(String status);

	DeveloperDTO getDeveloperById(Integer devId);

	List<DeveloperDTO> getDeveloperByReputation(Integer reputation);

	List<DeveloperDTO> getAllDevelopers();

	List<PostDTO> getPostsByDeveloper(Integer devId);

	List<DeveloperDTO> getByNoOfPosts(Integer noOfPosts);

	DeveloperDTO getByMaxReputation();

}
