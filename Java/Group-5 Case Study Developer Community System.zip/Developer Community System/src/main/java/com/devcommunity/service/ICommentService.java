package com.devcommunity.service;

import java.util.List;

import com.devcommunity.dto.CommentDTO;
import com.devcommunity.dto.VoteDTO;

public interface ICommentService {

	CommentDTO addComment(CommentDTO  comment);

	CommentDTO  updateComment(CommentDTO  comment);

	CommentDTO  removeComment(Integer respId);

	Integer getNoOfVotesOnCommentByVoteType(String  voteType, Integer commentId);

	CommentDTO  getByCommentId(Integer commentId);

	List<CommentDTO > getCommentsByPostId(Integer postId);

	List<CommentDTO > getCommentsByResponseId(Integer resId);
}
