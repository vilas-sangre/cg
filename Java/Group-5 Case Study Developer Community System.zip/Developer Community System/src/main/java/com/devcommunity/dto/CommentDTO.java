package com.devcommunity.dto;

import java.time.LocalDate;

public class CommentDTO {
	private Integer commentId;
	private String text;
	private DeveloperDTO createdBy;
	private LocalDate createdDate;
	private VoteDTO vote;
}
