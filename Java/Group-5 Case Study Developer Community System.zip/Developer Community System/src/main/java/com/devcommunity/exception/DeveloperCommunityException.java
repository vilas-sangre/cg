package com.devcommunity.exception;

public class DeveloperCommunityException extends Exception{
	public DeveloperCommunityException(String str) {
		super(str);
	}
}
