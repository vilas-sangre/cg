package com.devcommunity.entity;

import java.time.LocalDateTime;
import java.util.List;

public class Post {

	private Integer postId;
	private String query;
	private LocalDateTime postDateTime;
	private String topic;
	private Developer developer;
	private List<Response> listOfResponse;
	private List<Comment> listOfComment;
	private Integer noOfViews;
	private List<Vote> vote;
}
