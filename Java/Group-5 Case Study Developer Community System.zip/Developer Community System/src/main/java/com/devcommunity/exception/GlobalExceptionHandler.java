package com.devcommunity.exception;

public class GlobalExceptionHandler {
	
	
}