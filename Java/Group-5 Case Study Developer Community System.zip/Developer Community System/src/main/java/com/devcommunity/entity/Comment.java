package com.devcommunity.entity;

import java.time.LocalDate;

public class Comment {
	private Integer commentId;
	private String text;
	private Developer createdBy;
	private LocalDate createdDate;
	private Vote vote;
}
