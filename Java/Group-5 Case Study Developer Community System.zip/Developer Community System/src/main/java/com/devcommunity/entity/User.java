package com.devcommunity.entity;

public class User {

	private Integer userId;
	private String userName;
	private String userPassword;
	//Admin, Developers
	private String userRole;
	
}
