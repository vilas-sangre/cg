package com.devcommunity.service;

import java.time.LocalDate;
import java.util.List;

import com.devcommunity.dto.PostDTO;
import com.devcommunity.dto.VoteDTO;

public interface IPostService {

	PostDTO addPost(PostDTO post);

	PostDTO updatePost(PostDTO post);

	Integer getNoOfVotesOnPostByVoteType(String voteType, Integer postId);

	PostDTO getPostById(Integer postId);

	PostDTO removePost(Integer postId);

	List<PostDTO> getPostsByKeyword(String keyword);

	List<PostDTO> getPostsByTopic(String topic);

	List<PostDTO> getPostsByDate(LocalDate date);

}