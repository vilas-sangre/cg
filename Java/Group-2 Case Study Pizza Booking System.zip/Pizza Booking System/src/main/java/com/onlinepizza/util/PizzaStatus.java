package com.onlinepizza.util;

public enum PizzaStatus {

	BOOKED, CANCELLED, DELIVERED
}
