package com.onlinepizza.entity;

public class Customer extends User {
	private String customerName;
	private Long customerMobile;
	private String customerEmail;
	private String customerAddress;
	
}
