package com.onlinepizza.util;

public enum PizzaSize {
	SMALL , MEDIUM, LARGE;

}
