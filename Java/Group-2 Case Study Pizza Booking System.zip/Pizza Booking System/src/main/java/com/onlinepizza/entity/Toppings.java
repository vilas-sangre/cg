package com.onlinepizza.entity;

public class Toppings {
	private Integer toppingsId;
	private String toppingsName;
	private Double price;

}
