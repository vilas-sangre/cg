package com.onlinepizza.dto;

public class ToppingsDTO {
	private Integer toppingsId;
	private String toppingsName;
	private Double price;

}
